﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLSV.Data;

namespace QLSV
{
    public partial class frmThemLop : Form
    {
        public frmThemLop()
        {
            InitializeComponent();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (txtMaLop.Text.Trim() == "")
                MessageBox.Show("Mã lớp không được bỏ trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtMaLop.Text.Length > 8)
                MessageBox.Show("Mã lớp không vượt quá 8 ký tự!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (txtTenLop.Text.Trim() == "")
                MessageBox.Show("Tên lớp không được bỏ trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                QLSVEntities db = new QLSVEntities();
                Lop lop = new Lop();
                lop.MaLop = txtMaLop.Text;
                lop.TenLop = txtTenLop.Text;
                db.Lops.Add(lop);
                db.SaveChanges();

                MessageBox.Show("Thêm thành công!", "Hoàn thành", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}