﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLSV.Data;

namespace QLSV
{
    public partial class frmDanhSachLop : Form
    {
        public frmDanhSachLop()
        {
            InitializeComponent();
        }

        private void frmDanhSachLop_Load(object sender, EventArgs e)
        {
            dGV.AutoGenerateColumns = false;
            QLSVEntities db = new QLSVEntities();
            dGV.DataSource = db.Lops.ToList();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            frmThemLop fThem = new frmThemLop();
            fThem.ShowDialog();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string maLop = dGV.CurrentRow.Cells[0].Value.ToString();

            if (MessageBox.Show("Bạn có muốn xóa lớp " + maLop + " không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                QLSVEntities db = new QLSVEntities();
                Lop lop = db.Lops.Find(maLop);
                db.Lops.Remove(lop);
                db.SaveChanges();

                frmDanhSachLop_Load(sender, e);
            }
        }
    }
}